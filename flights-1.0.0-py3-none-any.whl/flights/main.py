from crypt import methods
from os import abort,environ
from flask import Flask, Blueprint, request, make_response 
from base64 import b64decode
from jwcrypto import jwt, jwk
import time

# from werkzeug.security import check_password_hash, generate_password_hash
from flights.db import get_db
import json
from jwcrypto import jwt

bp = Blueprint('main', __name__, url_prefix='/api/v1')
app = Flask(__name__)

##########################################################
##########################################################
##########################################################
@bp.route('/users', methods=['POST'])
def post_users():
  app.logger.info(">>>>POST /users")
  app.logger.info(f"Authorization: {request.headers['authorization']}") if "Authorization" in request.headers else app.logger.info("No Authorization")

  try:
    assert request.path == '/api/v1/users'
    assert request.method ==  'POST'
  except Exception as err:
    app.logger.info(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    resp.headers["Content-Type"]="application/json"
    return resp

  # Commented out because the logic trips AT
  # try:
  #   reqBody = request.get_json()
  #   app.logger.info(json.dumps(reqBody))
  #   authHeader = request.headers.get('authorization')
  #   if authHeader:
  #     authToken = authHeader.split(" ")[1]
  #     payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
  #     if not ("noname" in payload['name'].lower()):
  #       raise Exception(401)
  #     if payload['role'] == 'oper' and reqBody['role'] != 'user':
  #       raise Exception(403)
  #   else:
  #     if 'role' in reqBody and reqBody['role'] != 'user':
  #       raise Exception(403)
  # except Exception as err:
  #   app.logger.info(f"Unexpected {err=}, {type(err)=}")
  #   resp = make_response({"message": "Failure"},err.args[0] if err.args[0] is int else 400)
  #   resp.headers["Content-Type"]="application/json"
  #   return resp

  try:
    reqBody = request.get_json()
    requiredFields = ['username','password','email','app']
    for f in requiredFields:
      assert f in reqBody and reqBody[f]  
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},400)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    db = get_db()
    cur = db.cursor()
    insertStmt  = "INSERT INTO users (" + ",".join(requiredFields) + ") "
    insertStmt += "VALUES (" + ",".join(["?" for e in range(len(requiredFields))])  + ")"
    insertVals = [reqBody[f] for f in requiredFields]
    result = cur.execute(insertStmt,insertVals)
    app.logger.info(f"New user {reqBody['username']} with ID: {result.lastrowid}")
    db.commit()
    cur.close()
    resp = make_response(json.dumps({"message": "success"}),201)
    resp.headers["Content-Type"] = "application/json"
    return resp
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    if "POST_FLIGHTS_STATE" not in environ:
      resp = make_response({"message": "Failure"},400)
    else:
      resp = make_response({"message": "username already exists"},400)
    resp.headers["Content-Type"]="application/json"
    return resp
    

##########################################################
##########################################################
##########################################################
@bp.route('/tokens', methods=['POST'])
def post_login():
  app.logger.info(">>>>POST /tokens")
  app.logger.info(f"Authorization: {request.headers['authorization']}") if "Authorization" in request.headers else app.logger.info("No Authorization")
  user = ""
  passwd = ""

  try:
    authHeaderValue = request.headers.get('authorization').split(" ")[1]    
    app.logger.info(f"Basic {b64decode(authHeaderValue).decode()}")
    (user,passwd) = b64decode(authHeaderValue).decode().split(':')
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    db = get_db()
    cur = db.cursor()
    selectStmt = "SELECT role as role FROM users WHERE username=? AND password=?"
    cur.execute(selectStmt,[user,passwd])
    app.logger.debug(f"{user}:{passwd} combo found in the DB")
    selectResult = cur.fetchone()
    app.logger.debug(json.dumps(selectResult))
    role = selectResult['role']
    assert role
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp
  
  try:
    key = jwk.JWK().from_password("your-256-bit-secret")
    token = jwt.JWT(
      header = {"alg": "HS256","typ": "JWT"},
      claims = {"sub": f"12345_{user}",
                "name": f"{user} {passwd} noname",
                "role": role,
                "iat": int(time.time())}
    )
    token.make_signed_token(key)
    result = {"token": token.serialize()}
    resp = make_response(json.dumps(result),201)
    resp.headers["Content-Type"] = "application/json"
    return resp
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},400)
    resp.headers["Content-Type"]="application/json"
    return resp
    

##########################################################
##########################################################
##########################################################
@bp.route('/users', methods=['GET'])
def get_users():
  app.logger.info(">>>>GET /users")
  app.logger.info(f"Authorization: {request.headers['authorization']}") if "Authorization" in request.headers else app.logger.info("No Authorization")
  try:
    authHeader = request.headers.get('authorization')
    authToken = authHeader.split(" ")[1]
    payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
    if not ("noname" in payload['name'].lower()):
      raise Exception(401)
    if payload['role'] == 'user':
      raise Exception(403)
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},err.args[0] if err.args[0] is int else 400)
    resp.headers["Content-Type"]="application/json"
    return resp
  
  try:
    db = get_db()
    cur = db.cursor()
    rows = cur.execute("SELECT * FROM users").fetchall()
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    return resp
  finally:
    cur.close()


  if payload['role'] == 'admin':
    resp = make_response(json.dumps(rows))
  else:
    resp = make_response(json.dumps([row if row.pop('password',None) else row for row in rows]))
  resp.headers["Content-Type"] = "application/json"
  resp.headers["Result-Count"] = len(rows)

  return resp


##########################################################
##########################################################
##########################################################
@bp.route('/flights', methods=['GET'])
def get_flights():
  app.logger.info(">>>>GET /flights")
  db = get_db()
  app.logger.info(f"Authorization: {request.headers['authorization']}") if "Authorization" in request.headers else app.logger.info("No Authorization")
  app.logger.info('Destination: %s',request.args['destination']) if 'destination' in request.args else app.logger.info("No query params")
  
  try:
    authHeader = request.headers.get('authorization')
    authToken = authHeader.split(" ")[1]
    payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
    app.logger.info(f"name: {payload['name']}")
    assert "noname" in payload['name'].lower()
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    cur = db.cursor()
    if 'destination' in request.args:
      dest = request.args['destination']

      # Creates a finding, GET /flights?destination=ERROR
      if dest == 'ERROR':
        resp = make_response(json.dumps(
          {
            "error": "fatal", 
            "file": "main.py", 
            "line": 215, 
            "data": {"name": "George K","seat":"1A","ssn":"333-22-4444"}
          }),500)
        resp.headers["Content-Type"] = "application/json"
        return resp
      
      # Creates an Incident, GET /flights?destination=CLT union select * from flights
      if "union" in dest:
        resp = make_response(json.dumps({"message": "error"}),400)
        resp.headers["Content-Type"] = "application/json"
        return resp

      rows = cur.execute("SELECT * FROM flights WHERE destination = ? LIMIT 200", (dest,)).fetchall()
    else:
      rows = cur.execute("SELECT * FROM flights").fetchall()
    cur.close()
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    resp.headers["Content-Type"]="application/json"
    return resp
  finally:
    cur.close()
  
  resp = make_response(json.dumps(rows))
  resp.headers["Content-Type"] = "application/json"
  resp.headers["Result-Count"] = len(rows)

  return resp


##########################################################
##########################################################
##########################################################
@bp.route('/flights/<int:id>', methods=['GET'])
def get_flight_by_id(id):
  app.logger.info(">>>>GET /flights/{flight_id}")
  app.logger.info(f"Authorization: {request.headers['authorization']}") if "Authorization" in request.headers else app.logger.info("No Authorization")
  db = get_db()
  
  app.logger.info("flight_id: %s",id)

  try:
    authHeader = request.headers.get('authorization')
    authToken = authHeader.split(" ")[1]
    payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
    app.logger.info(f"name: {payload['name']}")
    assert "noname" in payload['name'].lower()
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    cur = db.cursor()
    row = cur.execute("SELECT * FROM flights WHERE id = ?", (id,)).fetchall()
    cur.close()
    if len(row) == 0:
      return "No record found", 404
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    resp.headers["Content-Type"]="application/json"
    return resp
  finally:
    cur.close()

  resp = make_response(json.dumps(row[0]))
  resp.headers["Content-Type"] = "application/json"

  return resp

##########################################################
##########################################################
##########################################################
@bp.route('/flights', methods=["POST"])
def post_flights():
  app.logger.info(">>>>POST /flights")
  app.logger.info(f"Authorization: {request.headers['authorization']}") if "Authorization" in request.headers else app.logger.info("No Authorization")
  
  assert request.path == '/api/v1/flights'
  assert request.method == 'POST'
  reqBody = request.get_json()
  app.logger.debug(json.dumps(reqBody))
  requiredFields = ['code','carrier','destination','origin','departure','price','plane','tseats','eseats']

  try:
    authHeader = request.headers.get('authorization')
    authToken = authHeader.split(" ")[1]
    payload = json.loads(jwt.JWT(jwt=authToken).token.objects['payload'])
    app.logger.info(f"name: {payload['name']}")
    assert "noname" in payload['name'].lower()
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},401)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    for f in requiredFields:
      assert f in reqBody and reqBody[f]
  except AssertionError as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},400)
    resp.headers["Content-Type"]="application/json"
    return resp

  try:
    db = get_db()
    cur = db.cursor()
    insertStmt = "INSERT INTO flights ("+ ",".join(requiredFields) +") VALUES (?,?,?,?,?,?,?,?,?)"
    app.logger.debug(insertStmt)
    insertVals = [reqBody[f] for f in requiredFields]
    result = cur.execute(insertStmt,insertVals)
    app.logger.info(f"New flight created wiht ID {result.lastrowid}")
    db.commit()
    if "POST_FLIGHTS_STATE" not in environ:
      resp = make_response({"message": "Success"}, 201)
    elif environ['POST_FLIGHTS_STATE'] == "flight_id":
      resp = make_response({"message": "Success","flight_id": result.lastrowid}, 201)
    else:
      resp = make_response({"message": "Success","bogus": result.lastrowid}, 201)
    resp.headers["Content-Type"]="application/json"
    return resp
  except Exception as err:
    app.logger.error(f"Unexpected {err=}, {type(err)=}")
    resp = make_response({"message": "Failure"},500)
    resp.headers["Content-Type"]="application/json"
    return resp
  finally:
    cur.close()
