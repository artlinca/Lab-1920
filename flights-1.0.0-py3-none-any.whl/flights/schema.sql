DROP TABLE IF EXISTS flights;
DROP TABLE IF EXISTS users;

CREATE TABLE flights (
  id INTEGER  PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL,
  carrier TEXT NOT NULL,
  destination TEXT NOT NULL,
  origin TEXT NOT NULL,
  departure TEXT NOT NULL,
  price INTEGER NOT NULL,
  plane TEXT NOT NULL,
  tseats INTEGER NOT NULL,
  eseats INTEGER NOT NULL
);

INSERT INTO flights (code,carrier,destination,origin,departure,price,plane,tseats,eseats)
       VALUES ("ABCD1234","American","CLT","LTH","2022-01-01",999,"Boeing 787",290,90);

INSERT INTO flights (code,carrier,destination,origin,departure,price,plane,tseats,eseats)
       VALUES ("BCDE2345","Delta","ILM","ATL","2022-01-02",200,"Boeing 737",190,30);

INSERT INTO flights (code,carrier,destination,origin,departure,price,plane,tseats,eseats)
       VALUES ("CDEF3456","El-Al","ATL","TLV","2022-01-01",1999,"Boeing 787",290,10);

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL,
  password TEXT NOT NULL,
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  app TEXT NOT NULL,
  UNIQUE(username)
);

INSERT INTO users (username,password,email,role,app)
       VALUES ("Super","Duper","super.duper@acme.com","admin","Flights App");
INSERT INTO users (username,password,email,role,app)
       VALUES ("Admin","Duper","admin.duper@acme.com","admin","Flights App");
INSERT INTO users (username,password,email,role,app)
       VALUES ("John","Doe","John.Doe@acme.com","oper","Flights App");
INSERT INTO users (username,password,email,role,app)
       VALUES ("Jane","Doe","John.Doe@acme.com","oper","Flights App");
INSERT INTO users (username,password,email,app)
       VALUES ("Jack","Smith","Jack.Smith@acme.com","Flights App");
INSERT INTO users (username,password,email,app)
       VALUES ("Jacky","Smith","Jacky.Smith@acme.com","Flights App");
